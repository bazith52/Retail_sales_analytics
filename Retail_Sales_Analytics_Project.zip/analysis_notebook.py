import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sqlite3
from pathlib import Path

Path("output").mkdir(exist_ok=True)

df = pd.read_csv("output/retail_sales_clean.csv")
df["order_date"] = pd.to_datetime(df["order_date"])
df["month"] = df["order_date"].dt.to_period("M").astype(str)

kpis = {
    "total_sales": round(df["sales"].sum(), 2),
    "total_profit": round(df["profit"].sum(), 2),
    "orders": int(df.shape[0]),
    "aov": round(df["sales"].mean(), 2),
    "return_rate_pct": round(100 * df["returned"].mean(), 2)
}

monthly = df.groupby("month", as_index=False)[["sales", "profit"]].sum()
cat = df.groupby("category", as_index=False)[["sales", "profit"]].sum().sort_values("sales", ascending=False)
region = df.groupby("region", as_index=False)["sales"].sum().sort_values("sales", ascending=False)
channel = df.groupby("channel", as_index=False)["sales"].sum().sort_values("sales", ascending=False)

plt.style.use("seaborn-v0_8-whitegrid")

fig, ax = plt.subplots(figsize=(10,5))
ax.plot(monthly["month"], monthly["sales"], marker="o")
ax.set_title("Monthly Sales Trend")
ax.set_xlabel("Month")
ax.set_ylabel("Sales")
ax.tick_params(axis='x', rotation=45)
fig.tight_layout()
fig.savefig("output/monthly_sales_trend.png", dpi=200)
plt.close(fig)

fig, ax = plt.subplots(figsize=(9,5))
ax.bar(cat["category"], cat["sales"])
ax.set_title("Sales by Category")
ax.set_xlabel("Category")
ax.set_ylabel("Sales")
ax.tick_params(axis='x', rotation=30)
fig.tight_layout()
fig.savefig("output/sales_by_category.png", dpi=200)
plt.close(fig)

fig, ax = plt.subplots(figsize=(8,5))
ax.bar(region["region"], region["sales"], color="#4C78A8")
ax.set_title("Sales by Region")
ax.set_xlabel("Region")
ax.set_ylabel("Sales")
fig.tight_layout()
fig.savefig("output/sales_by_region.png", dpi=200)
plt.close(fig)

fig, ax = plt.subplots(figsize=(8,5))
ax.pie(channel["sales"], labels=channel["channel"], autopct="%1.1f%%", startangle=90)
ax.set_title("Sales by Channel")
fig.tight_layout()
fig.savefig("output/sales_by_channel.png", dpi=200)
plt.close(fig)

summary = pd.DataFrame([kpis])
summary.to_csv("output/kpi_summary.csv", index=False)
print(summary.to_string(index=False))
