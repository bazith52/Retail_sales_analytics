-- Retail Sales Analytics SQL Workbook
-- Dataset: output/retail_sales.db table: sales

-- 1. Total sales by month
SELECT strftime('%Y-%m', order_date) AS month, ROUND(SUM(sales),2) AS total_sales FROM sales GROUP BY 1 ORDER BY 1;

-- 2. Top categories by sales
SELECT category, ROUND(SUM(sales),2) AS total_sales FROM sales GROUP BY 1 ORDER BY total_sales DESC;

-- 3. Sales by region
SELECT region, ROUND(SUM(sales),2) AS total_sales FROM sales GROUP BY 1 ORDER BY total_sales DESC;

-- 4. Sales by channel
SELECT channel, ROUND(SUM(sales),2) AS total_sales FROM sales GROUP BY 1 ORDER BY total_sales DESC;

-- 5. Profit by category
SELECT category, ROUND(SUM(profit),2) AS total_profit FROM sales GROUP BY 1 ORDER BY total_profit DESC;

-- 6. Average order value by segment
SELECT segment, ROUND(AVG(sales),2) AS aov FROM sales GROUP BY 1 ORDER BY aov DESC;

-- 7. Returned orders by category
SELECT category, SUM(returned) AS returned_orders FROM sales GROUP BY 1 ORDER BY returned_orders DESC;

-- 8. Monthly sales trend
SELECT strftime('%Y-%m', order_date) AS month, ROUND(SUM(sales),2) AS total_sales, ROUND(SUM(profit),2) AS total_profit FROM sales GROUP BY 1 ORDER BY 1;

-- 9. Top products by sales
SELECT product, ROUND(SUM(sales),2) AS total_sales FROM sales GROUP BY 1 ORDER BY total_sales DESC LIMIT 10;

-- 10. Delivery days by channel
SELECT channel, ROUND(AVG(delivery_days),2) AS avg_delivery_days FROM sales GROUP BY 1;

-- 11. High value orders
SELECT * FROM sales WHERE sales > (SELECT AVG(sales) FROM sales) ORDER BY sales DESC LIMIT 20;

-- 12. Customer lifetime value
SELECT customer_id, customer_name, ROUND(SUM(sales),2) AS clv FROM sales GROUP BY 1,2 ORDER BY clv DESC LIMIT 20;

-- 13. Sales by region and category
SELECT region, category, ROUND(SUM(sales),2) AS total_sales FROM sales GROUP BY 1,2 ORDER BY 1,3 DESC;

-- 14. Return rate by channel
SELECT channel, ROUND(100.0*SUM(returned)/COUNT(*),2) AS return_rate_pct FROM sales GROUP BY 1;

-- 15. Profit margin by category
SELECT category, ROUND(100.0*SUM(profit)/SUM(sales),2) AS profit_margin_pct FROM sales GROUP BY 1 ORDER BY profit_margin_pct DESC;

-- 16. Repeat customers
SELECT COUNT(*) AS repeat_customers FROM (SELECT customer_id FROM sales GROUP BY customer_id HAVING COUNT(*) > 1);

